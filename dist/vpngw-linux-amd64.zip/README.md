# vpngw

`vpngw` is a Linux server utility for selective traffic routing through WireGuard uplink:
- clients connect to `wg-clients`;
- default route is direct internet;
- blocked/unreachable destinations are pinned to VPN via `wg-uplink`;
- supports all IP protocols by L3/L4 policy routing (`nftables + ip rule`).

## Components

- `vpngw server`:
  - DNS forwarder (`:53`) with fallback to VPN upstream.
  - policy engine with persistent cache.
  - HTTP API (`/v1/report`, `/v1/clients`, `/v1/domains`).
  - dataplane manager for nft/ip rules.
- `vpngw gen-client`: create WireGuard client peer and print router-ready config.

## Build

```bash
go build -o vpngw ./cmd/vpngw
install -m 0755 vpngw /usr/local/bin/vpngw
```

## Quick Setup

1. Automatic root install (from release folder):

```bash
chmod +x install.sh
./install.sh
```

This will:
- install `vpngw` to `/opt/vpngw`;
- bring up `wg-uplink` and `wg-clients`;
- start `vpngw.service`;
- generate 3 client configs in `/opt/vpngw/clients/router-{1..3}.conf`.

2. Manual path (optional):
- prepare `wg-clients`: server interface where end routers connect.
- prepare `wg-uplink`: upstream tunnel used for bypass routing.

3. Copy config:

```bash
mkdir -p /etc/vpngw
cp deploy/config.example.json /etc/vpngw/config.json
```

4. Edit `/etc/vpngw/config.json`:
- set `wireguard.server_endpoint`;
- set `wireguard.server_public_key`;
- set DNS upstreams (`dns.direct_upstream`, `dns.vpn_upstream`);
- set API token.

5. Enable forwarding and systemd service:

```bash
bash deploy/scripts/bootstrap_linux.sh
cp deploy/systemd/vpngw.service /etc/systemd/system/vpngw.service
systemctl daemon-reload
systemctl enable --now vpngw
```

## Generate end-client config

```bash
vpngw gen-client -config /etc/vpngw/config.json -name router-kitchen
```

Or via API:

```bash
curl -sS -X POST http://127.0.0.1:18080/v1/clients \
  -H 'Authorization: Bearer change-me' \
  -H 'Content-Type: application/json' \
  -d '{"name":"router-kitchen"}'
```

## Report blocked destination (instant policy update)

Use from any script/agent/router hook:

```bash
curl -sS -X POST http://127.0.0.1:18080/v1/report \
  -H 'Authorization: Bearer change-me' \
  -H 'Content-Type: application/json' \
  -d '{"domain":"modrinth.com","ips":["104.26.12.8"],"reason":"connect_timeout"}'
```

`vpngw` will:
- increase failure score for domain;
- after threshold, pin destination to `FORCE_VPN`;
- add resolved IPs to nft set with TTL.

## API

- `GET /healthz`
- `POST /v1/report`
- `GET /v1/domains`
- `GET /v1/clients`
- `POST /v1/clients`

## Notes

- DNS must go through this server for automatic domain processing.
- if clients use external DoH/DoT directly, server cannot always map domain reliably.
- dataplane operations require root and `CAP_NET_ADMIN`.
