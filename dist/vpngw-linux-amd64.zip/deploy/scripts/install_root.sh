#!/usr/bin/env bash
set -euo pipefail

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Run as root"
  exit 1
fi

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PKG_DIR="$(cd "${BASE_DIR}/.." && pwd)"

mkdir -p /opt/vpngw /var/lib/vpngw /opt/vpngw/clients /etc/wireguard /etc/systemd/system

cp -f "${PKG_DIR}/vpngw" /opt/vpngw/vpngw
cp -f "${PKG_DIR}/config.json" /opt/vpngw/config.json
cp -f "${PKG_DIR}/vpngw.service" /etc/systemd/system/vpngw.service
cp -f "${BASE_DIR}/wireguard/wg-uplink.conf" /etc/wireguard/wg-uplink.conf
cp -f "${BASE_DIR}/wireguard/wg-clients.conf" /etc/wireguard/wg-clients.conf

chmod 0755 /opt/vpngw/vpngw
chmod 0600 /etc/wireguard/wg-uplink.conf /etc/wireguard/wg-clients.conf
chmod 0644 /etc/systemd/system/vpngw.service

if grep -q "__WG_CLIENTS_PRIVATE_KEY__" /etc/wireguard/wg-clients.conf; then
  WG_PRIV="$(wg genkey)"
  sed -i "s|__WG_CLIENTS_PRIVATE_KEY__|${WG_PRIV}|g" /etc/wireguard/wg-clients.conf
fi

WG_CLIENTS_PUB="$(awk -F'=' '/PrivateKey/{gsub(/ /, \"\", $2); print $2}' /etc/wireguard/wg-clients.conf | wg pubkey)"

python3 - "$WG_CLIENTS_PUB" <<'PY'
import json, sys
p = "/opt/vpngw/config.json"
pub = sys.argv[1].strip()
with open(p, "r", encoding="utf-8") as f:
    cfg = json.load(f)
cfg.setdefault("wireguard", {})
cfg["wireguard"]["server_public_key"] = pub
with open(p, "w", encoding="utf-8") as f:
    json.dump(cfg, f, ensure_ascii=False, indent=2)
PY

cat >/etc/sysctl.d/99-vpngw.conf <<EOF
net.ipv4.ip_forward=1
net.ipv6.conf.all.forwarding=1
EOF
sysctl --system >/dev/null

systemctl daemon-reload
systemctl enable --now wg-quick@wg-uplink
systemctl enable --now wg-quick@wg-clients
systemctl enable --now vpngw

for n in 1 2 3; do
  /opt/vpngw/vpngw gen-client -config /opt/vpngw/config.json -name "router-${n}" >"/opt/vpngw/clients/router-${n}.txt"
  awk 'f{print} /^$/{f=1}' "/opt/vpngw/clients/router-${n}.txt" >"/opt/vpngw/clients/router-${n}.conf"
done

echo "Done."
echo "Client configs:"
ls -1 /opt/vpngw/clients/router-*.conf

