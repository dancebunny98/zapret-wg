Single binary build (Linux ELF).
Default install target: /root/proga
Run as root:
  chmod +x vpngw
  ./vpngw bootstrap -clients 3